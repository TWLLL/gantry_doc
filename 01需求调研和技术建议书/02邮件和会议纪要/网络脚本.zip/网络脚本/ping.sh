rm -f info.txt
fping -u -f ip.txt >info.txt
IP=info.txt
TIME=$(date "+%Y-%m-%d %H:%M:%S")
for i in `cat $IP`
do
mysql -h10.80.230.130 -uroot -pqljt123 -N -e "use gantry_inner;insert into net_connect_info (IP,CREATE_TIME,ERROR_TYPE,STATUS,UPDATE_TIME) values ('$i','$TIME',1,0,now());"
done
